# Los Plikos TV 1.0

Natywny menedżer plików dla Android TV 12, napisany w Java (Android SDK). Projekt można otworzyć w Android Studio. Interfejs obsługuje pilot D-pad: strzałki, OK, Wstecz i opcjonalnie Menu / długie OK. Zaprojektowany do działania w orientacji poziomej.

## Funkcje

- Motyw **AMOLED Dark** i **Light**, zapamiętywany po ponownym uruchomieniu.
- Nowoczesne wektorowe ikony; launcher i baner Android TV.
- Pamięć współdzielona Android TV i nośniki USB (jeśli telewizor wystawia ich katalogi aplikacjom).
- FTP zwykły (port 21, domyślnie PASV, binarny transfer).
- SMB **dokładnie 1.0** (port 445 domyślnie, wymuszenie minVersion=SMB1 i maxVersion=SMB1).
- Lista plików i folderów, wejście/wyjście, tworzenie folderu, zmiana nazwy, kopiowanie, przenoszenie, usuwanie oraz pobieranie do Pobranych.
- Kopiowanie/przenoszenie między pamięcią telewizora, FTP i SMB1, również folderów, strumieniowo (nie potrzeba drugiej kopii w cache podczas transferu).
- Otwieranie plików lokalnych w aplikacjach zainstalowanych na telewizorze (Intent.ACTION_VIEW); małe pliki z serwerów są wcześniej pobierane do cache.
- Zapisywanie serwerów: nazwa, host, port, login, udział SMB i domena. **Hasła nie są zapisywane**; trzeba je wpisać przy nowym połączeniu.

## Jak skompilować i uzyskać APK

**W tym środowisku nie było Android SDK, dlatego nie zbudowano ani nie testowano binarnego APK.** Projekt zawiera rzeczywisty kod źródłowy i konfigurację Gradle, ale wymaga kompilacji i sprawdzenia na telewizorze.

1. Na komputerze zainstaluj **Android Studio** (z JDK 17) i **Android SDK 35**.
2. Rozpakuj ZIP z projektem. W Android Studio użyj **File → Open** i wybierz katalog `LosPlikosTV`.
3. Projekt korzysta z Android Gradle Plugin **8.7.3** i wymaga **Gradle 8.9**. Jeśli Android Studio pyta o Gradle, wskaż lokalną dystrybucję 8.9 lub w terminalu z zainstalowanym Gradle uruchom `gradle wrapper --gradle-version 8.9`, następnie `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). Zależności muszą być pobrane z internetu.
4. Po synchronizacji wybierz w Android Studio **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Po prawidłowej kompilacji plik APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.
6. Prześlij APK na telewizor (USB lub sieć) i zainstaluj po zezwoleniu na instalacje z danego źródła. Aplikacja pojawi się w launcherze Android TV.

## Android TV 12 i uprawnienia

- Aplikacja wymaga `INTERNET` oraz prosi o uprawnienie **Zarządzaj wszystkimi plikami** (`MANAGE_EXTERNAL_STORAGE`). Na Android TV ekran tego uprawnienia może nie istnieć. W takim wypadku system ograniczy dostęp do współdzielonych plików / USB i nie jest to coś, co aplikacja może legalnie obejść.
- Aplikacja próbuje także standardowego odczytu `READ_EXTERNAL_STORAGE` jako ograniczony plan awaryjny na Android TV 12.
- Ograniczone pozostają foldery innych aplikacji (`Android/data`, `Android/obb`) nawet po udzieleniu szerokich uprawnień.
- Nie wszystkie telewizory udostępniają zamontowany USB jako `StorageVolume.getDirectory()`.

## Połączenie z FTP

- **Serwer:** np. `192.168.1.50`.
- **Port:** `21`.
- **Użytkownik:** np. `anonymous` albo konto serwera.
- **Hasło:** hasło danego konta.
- FTP jest klientem, nie serwerem FTP. Aplikacja nie udostępnia katalogów TV przez FTP.

## Połączenie z SMB1

- **Serwer:** np. `192.168.1.50`.
- **Port:** zwykle `445`.
- **Udział SMB:** nazwa udostępnionego folderu, np. `Filmy` (bez ukośników).
- **Użytkownik/hasło:** konto serwera SMB1; domena może pozostać pusta.
- SMB2/SMB3 celowo nie są negocjowane. Jeśli serwer wyłączył SMB1, połączenie się nie powiedzie.

## Uwaga bezpieczeństwa

SMB1 i nieszyfrowany FTP są podatne na przechwycenie lub manipulację ruchem. Używaj tylko w kontrolowanej sieci domowej, **nie wystawiaj portów FTP/SMB1 do internetu**. W miarę możliwości na serwerach włącz SMB2/SMB3 i FTPS/SFTP, chociaż te protokoły nie są obecnie obsługiwane przez tę wersję aplikacji.

Kopiowanie i usuwanie mają charakter bezpośredni, bez kosza. Przerwany transfer może zostawić częściowo zapisany plik. Nie ma obsługi działań w tle, kolejkowania transferów ani paska procentowego dla każdego pliku. Testy na konkretnym modelu Android TV i na rzeczywistych serwerach FTP/SMB1 są nadal potrzebne.

## Zależności

- AndroidX Core 1.13.1 (FileProvider)
- Apache Commons Net 3.13.0 (FTP, licencja Apache 2.0)
- jCIFS-NG 2.1.10 (SMB1, licencja LGPL)

Kod źródłowy jest dostępny w `app/src/main/java/pl/n2s/losplikostv/`.
