package pl.n2s.losplikostv;

import android.net.Uri;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;

final class Filesystems {
    private Filesystems() {}

    static final class Entry {
        final String name, path;
        final boolean directory;
        final long size, modified;
        Entry(String name, String path, boolean directory, long size, long modified) {
            this.name = name; this.path = path; this.directory = directory;
            this.size = size; this.modified = modified;
        }
    }

    interface Store {
        String label();
        String root();
        String child(String parent, String name);
        String parent(String path);
        List<Entry> list(String path) throws Exception;
        boolean exists(String path) throws Exception;
        void mkdir(String path) throws Exception;
        void rename(String from, String to) throws Exception;
        void delete(String path) throws Exception;
        InputStream read(String path) throws Exception;
        OutputStream write(String path) throws Exception;
    }

    static String cleanName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.equals(".") || n.equals("..") || n.contains("/")
                || n.contains("\\") || n.indexOf('\u0000') != -1) {
            throw new IllegalArgumentException("Niedozwolona nazwa pliku lub folderu");
        }
        return n;
    }

    static List<Entry> sorted(List<Entry> entries) {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                if (a.directory != b.directory) return a.directory ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return entries;
    }

    static final class Local implements Store {
        private final String root;
        Local(String root) throws IOException { this.root = new File(root).getCanonicalPath(); }
        @Override public String root() { return root; }
        @Override public String label() { return "Pamięć / USB"; }
        private File checked(String path) throws IOException {
            File file = new File(path);
            String canonical = file.getCanonicalPath();
            if (!canonical.equals(root) && !canonical.startsWith(root + File.separator)) {
                throw new IOException("Ścieżka poza wybranym dyskiem");
            }
            return file;
        }
        @Override public String child(String parent, String name) {
            return new File(parent, cleanName(name)).getPath();
        }
        @Override public String parent(String path) {
            if (path.equals(root)) return root;
            File parent = new File(path).getParentFile();
            if (parent == null) return root;
            String result = parent.getPath();
            return result.length() < root.length() ? root : result;
        }
        @Override public List<Entry> list(String path) throws Exception {
            File dir = checked(path);
            if (!dir.isDirectory()) throw new IOException("Folder jest niedostępny. Sprawdź uprawnienia.");
            File[] files = dir.listFiles();
            if (files == null) throw new IOException("Brak uprawnień do odczytu folderu");
            List<Entry> entries = new ArrayList<>();
            for (File f : files) {
                // Symlinków nie otwieramy, aby nie przejść poza wybrany katalog.
                if (Files.isSymbolicLink(f.toPath())) continue;
                entries.add(new Entry(f.getName(), f.getPath(), f.isDirectory(), f.length(), f.lastModified()));
            }
            return sorted(entries);
        }
        @Override public boolean exists(String path) throws Exception { return checked(path).exists(); }
        @Override public void mkdir(String path) throws Exception {
            if (!checked(path).mkdir()) throw new IOException("Nie można utworzyć folderu");
        }
        @Override public void rename(String from, String to) throws Exception {
            File src = checked(from), dst = checked(to);
            if (dst.exists() || !src.renameTo(dst)) throw new IOException("Nie można zmienić nazwy");
        }
        @Override public void delete(String path) throws Exception {
            File f = checked(path);
            if (path.equals(root)) throw new IOException("Nie można usunąć głównego katalogu");
            if (Files.isSymbolicLink(f.toPath())) throw new IOException("Operacja na dowiązaniu zabroniona");
            if (f.isDirectory()) {
                File[] kids = f.listFiles();
                if (kids == null) throw new IOException("Nie można odczytać zawartości folderu");
                for (File child : kids) delete(child.getPath());
            }
            if (!f.delete()) throw new IOException("Nie można usunąć: " + f.getName());
        }
        @Override public InputStream read(String path) throws Exception { return new FileInputStream(checked(path)); }
        @Override public OutputStream write(String path) throws Exception {
            File f = checked(path);
            if (f.exists()) throw new IOException("Plik docelowy już istnieje");
            return new FileOutputStream(f);
        }
    }

    static final class Endpoint {
        String type, title, host, user, domain, share, password;
        int port;
        Endpoint(String type, String title, String host, int port, String user,
                 String domain, String share, String password) {
            this.type = type; this.title = title; this.host = host; this.port = port;
            this.user = user; this.domain = domain; this.share = share; this.password = password;
        }
        String description() {
            return type.toUpperCase() + "  •  " + host + ":" + port
                    + ("smb".equals(type) ? "/" + share : "");
        }
    }

    static final class Ftp implements Store {
        final Endpoint ep;
        Ftp(Endpoint ep) { this.ep = ep; }
        @Override public String label() { return ep.title; }
        @Override public String root() { return "/"; }
        @Override public String child(String parent, String name) {
            return (parent.equals("/") ? "/" : parent + "/") + cleanName(name);
        }
        @Override public String parent(String path) {
            if (path.equals("/")) return "/";
            int i = path.lastIndexOf('/'); return i <= 0 ? "/" : path.substring(0, i);
        }
        private FTPClient connect() throws IOException {
            FTPClient c = new FTPClient();
            c.setConnectTimeout(9000);
            c.setDefaultTimeout(12000);
            c.setDataTimeout(java.time.Duration.ofSeconds(35));
            c.setControlEncoding("UTF-8");
            try {
                c.connect(ep.host, ep.port);
                if (!FTPReply.isPositiveCompletion(c.getReplyCode())) throw new IOException("Serwer FTP odrzucił połączenie");
                if (!c.login(ep.user.isEmpty() ? "anonymous" : ep.user, ep.password))
                    throw new IOException("Nieprawidłowy login lub hasło FTP");
                c.enterLocalPassiveMode();
                if (!c.setFileType(FTP.BINARY_FILE_TYPE)) throw new IOException("Nie można włączyć transferu binarnego");
                return c;
            } catch (Exception e) {
                quit(c);
                throw e instanceof IOException ? (IOException) e : new IOException(e);
            }
        }
        private static void quit(FTPClient c) {
            try { if (c.isConnected()) c.logout(); } catch (Exception ignored) {}
            try { if (c.isConnected()) c.disconnect(); } catch (Exception ignored) {}
        }
        @Override public List<Entry> list(String path) throws Exception {
            FTPClient c = connect();
            try {
                FTPFile[] files = c.listFiles(path);
                if (files == null) throw new IOException("Nie można wyświetlić katalogu FTP: " + c.getReplyString());
                List<Entry> out = new ArrayList<>();
                for (FTPFile f : files) {
                    String name = f.getName();
                    if (name == null || name.equals(".") || name.equals("..") || f.isSymbolicLink()) continue;
                    if (name.contains("/") || name.contains("\\")) continue;
                    out.add(new Entry(name, child(path, name), f.isDirectory(), f.getSize(),
                            f.getTimestamp() == null ? 0 : f.getTimestamp().getTimeInMillis()));
                }
                return sorted(out);
            } finally { quit(c); }
        }
        @Override public boolean exists(String path) throws Exception {
            if (path.equals("/")) return true;
            String dir = parent(path), name = path.substring(path.lastIndexOf('/') + 1);
            for (Entry e : list(dir)) if (e.name.equals(name)) return true;
            return false;
        }
        @Override public void mkdir(String path) throws Exception {
            FTPClient c = connect();
            try { if (!c.makeDirectory(path)) throw new IOException("FTP: błąd tworzenia folderu: " + c.getReplyString()); }
            finally { quit(c); }
        }
        @Override public void rename(String from, String to) throws Exception {
            FTPClient c = connect();
            try { if (!c.rename(from, to)) throw new IOException("FTP: nie udało się zmienić nazwy"); }
            finally { quit(c); }
        }
        @Override public void delete(String path) throws Exception {
            if (path.equals("/")) throw new IOException("Nie można usunąć katalogu głównego FTP");
            boolean dir = false;
            for (Entry e : list(parent(path))) if (e.path.equals(path)) { dir = e.directory; break; }
            if (dir) for (Entry e : list(path)) delete(e.path);
            FTPClient c = connect();
            try {
                boolean ok = dir ? c.removeDirectory(path) : c.deleteFile(path);
                if (!ok) throw new IOException("FTP: odmowa usunięcia " + path);
            } finally { quit(c); }
        }
        @Override public InputStream read(String path) throws Exception {
            FTPClient c = connect();
            InputStream in = c.retrieveFileStream(path);
            if (in == null) { quit(c); throw new IOException("FTP: nie można pobrać " + path); }
            return new FilterInputStream(in) {
                boolean closed;
                @Override public void close() throws IOException {
                    if (closed) return;
                    closed = true;
                    IOException problem = null;
                    try { super.close(); } catch (IOException e) { problem = e; }
                    try { if (!c.completePendingCommand() && problem == null) problem = new IOException("FTP: niepełny transfer"); }
                    catch (IOException e) { if (problem == null) problem = e; }
                    finally { quit(c); }
                    if (problem != null) throw problem;
                }
            };
        }
        @Override public OutputStream write(String path) throws Exception {
            FTPClient c = connect();
            OutputStream out = c.storeFileStream(path);
            if (out == null) { quit(c); throw new IOException("FTP: brak dostępu do zapisu " + path); }
            return new FilterOutputStream(out) {
                boolean closed;
                @Override public void close() throws IOException {
                    if (closed) return;
                    closed = true;
                    IOException problem = null;
                    try { super.close(); } catch (IOException e) { problem = e; }
                    try { if (!c.completePendingCommand() && problem == null) problem = new IOException("FTP: niepełny zapis"); }
                    catch (IOException e) { if (problem == null) problem = e; }
                    finally { quit(c); }
                    if (problem != null) throw problem;
                }
            };
        }
    }

    static final class Smb1 implements Store {
        final Endpoint ep;
        final CIFSContext context;
        Smb1(Endpoint ep) throws Exception {
            this.ep = ep;
            Properties p = new Properties();
            p.setProperty("jcifs.smb.client.minVersion", "SMB1");
            p.setProperty("jcifs.smb.client.maxVersion", "SMB1");
            p.setProperty("jcifs.smb.client.connTimeout", "9000");
            p.setProperty("jcifs.smb.client.responseTimeout", "15000");
            p.setProperty("jcifs.smb.client.soTimeout", "20000");
            context = new BaseContext(new PropertyConfiguration(p)).withCredentials(
                    new NtlmPasswordAuthenticator(ep.domain, ep.user, ep.password));
        }
        @Override public String label() { return ep.title; }
        @Override public String root() { return "/"; }
        @Override public String child(String parent, String name) {
            return (parent.equals("/") ? "/" : parent + "/") + cleanName(name);
        }
        @Override public String parent(String path) {
            if (path.equals("/")) return "/";
            int i = path.lastIndexOf('/'); return i <= 0 ? "/" : path.substring(0, i);
        }
        private SmbFile smb(String path, boolean dir) throws Exception {
            StringBuilder u = new StringBuilder("smb://").append(ep.host).append(":")
                    .append(ep.port).append("/").append(Uri.encode(ep.share)).append("/");
            for (String part : path.split("/")) if (!part.isEmpty()) u.append(Uri.encode(part)).append('/');
            if (!dir && !path.equals("/")) u.setLength(u.length() - 1);
            return new SmbFile(u.toString(), context);
        }
        @Override public List<Entry> list(String path) throws Exception {
            try (SmbFile dir = smb(path, true)) {
                SmbFile[] children = dir.listFiles();
                if (children == null) throw new IOException("Nie można wyświetlić udziału SMB1");
                List<Entry> out = new ArrayList<>();
                for (SmbFile f : children) {
                    try (SmbFile item = f) {
                        String name = item.getName();
                        if (name.endsWith("/")) name = name.substring(0, name.length() - 1);
                        if (name.isEmpty() || name.equals(".") || name.equals("..") || name.contains("/")) continue;
                        boolean isDir = item.isDirectory();
                        out.add(new Entry(name, child(path, name), isDir,
                                isDir ? 0 : item.length(), item.lastModified()));
                    }
                }
                return sorted(out);
            }
        }
        @Override public boolean exists(String path) throws Exception {
            try (SmbFile f = smb(path, false)) { return f.exists(); }
        }
        @Override public void mkdir(String path) throws Exception {
            try (SmbFile f = smb(path, true)) { f.mkdir(); }
        }
        @Override public void rename(String from, String to) throws Exception {
            try (SmbFile src = smb(from, false); SmbFile dst = smb(to, false)) { src.renameTo(dst); }
        }
        @Override public void delete(String path) throws Exception {
            if (path.equals("/")) throw new IOException("Nie można usunąć udziału SMB");
            try (SmbFile f = smb(path, false)) { f.delete(); }
        }
        @Override public InputStream read(String path) throws Exception {
            SmbFile file = smb(path, false);
            try {
                InputStream stream = file.getInputStream();
                return new FilterInputStream(stream) {
                    @Override public void close() throws IOException {
                        try { super.close(); } finally { file.close(); }
                    }
                };
            } catch (Exception e) { file.close(); throw e; }
        }
        @Override public OutputStream write(String path) throws Exception {
            SmbFile file = smb(path, false);
            try {
                if (file.exists()) throw new IOException("Plik docelowy już istnieje");
                OutputStream stream = file.getOutputStream();
                return new FilterOutputStream(stream) {
                    @Override public void close() throws IOException {
                        try { super.close(); } finally { file.close(); }
                    }
                };
            } catch (Exception e) { file.close(); throw e; }
        }
    }

    /** Stream-based copy, including directories, with no intermediate 2x file on disk. */
    static void copy(Store source, Entry item, Store target, String destination) throws Exception {
        if (item.directory) {
            target.mkdir(destination);
            for (Entry child : source.list(item.path)) {
                copy(source, child, target, target.child(destination, child.name));
            }
        } else {
            try (InputStream in = source.read(item.path); OutputStream out = target.write(destination)) {
                byte[] buffer = new byte[65536];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.flush();
            }
        }
    }

    static String uniqueName(Store to, String folder, String name, boolean directory) throws Exception {
        String candidate = to.child(folder, name);
        if (!to.exists(candidate)) return candidate;
        String base = name, ext = "";
        int dot = name.lastIndexOf('.');
        if (!directory && dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        for (int i = 1; i < 1000; i++) {
            candidate = to.child(folder, base + " (" + i + ")" + ext);
            if (!to.exists(candidate)) return candidate;
        }
        throw new IOException("Za dużo elementów o tej samej nazwie");
    }
}
