package pl.n2s.losplikostv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.webkit.MimeTypeMap;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** TV-first file manager: remote control focus, local volumes, FTP, SMB1, dark/light UI. */
public final class MainActivity extends Activity {
    private static final String PREF = "losplikos_ui";
    private final ExecutorService workers = Executors.newSingleThreadExecutor();
    private final List<Filesystems.Endpoint> bookmarks = new ArrayList<>();
    private SharedPreferences prefs;
    private boolean dark, firstPermissionPrompt = true, requestListFocus;
    private int bg, panel, panelAlt, fg, subtle, accent, border;
    private Filesystems.Store current;
    private String currentPath;
    private Filesystems.Store clipboardStore;
    private Filesystems.Entry clipboardItem;
    private boolean clipboardMove;
    private int generation = 0;
    private LinearLayout sidebar, fileColumn;
    private TextView pathView, heading, foot;
    private String statusText = "Gotowe";

    @Override protected void onCreate(Bundle state) {
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        dark = prefs.getBoolean("dark", true);
        setTheme(dark ? R.style.AppThemeDark : R.style.AppTheme);
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        loadBookmarks();
        try {
            current = new Filesystems.Local(Environment.getExternalStorageDirectory().getAbsolutePath());
            currentPath = current.root();
        } catch (Exception ex) {
            try { current = new Filesystems.Local(getFilesDir().getAbsolutePath()); }
            catch (Exception fatal) { throw new IllegalStateException(fatal); }
            currentPath = current.root();
        }
        buildUi();
        loadFolder(current, currentPath, null);
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
            }
            new android.os.Handler(getMainLooper()).postDelayed(this::explainPermission, 1600);
        }
    }

    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density*n+0.5f); }
    private void palette() {
        bg = Color.parseColor(dark ? "#0B111B" : "#F4F7FA");
        panel = Color.parseColor(dark ? "#141E2C" : "#FFFFFF");
        panelAlt = Color.parseColor(dark ? "#1C2939" : "#ECF2F5");
        fg = Color.parseColor(dark ? "#F3F7FC" : "#182231");
        subtle = Color.parseColor(dark ? "#97A9B9" : "#617083");
        accent = Color.parseColor(dark ? "#3DD9AA" : "#087E65");
        border = Color.parseColor(dark ? "#29394A" : "#DAE3EC");
    }
    private GradientDrawable box(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private TextView text(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }
    private TextView action(String label, int icon, boolean prominent, Runnable click) {
        TextView t = text(label, 14, fg, false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(13),dp(9),dp(13),dp(9));
        if (icon >= 0) {
            ModernIcon d = new ModernIcon(icon, prominent ? accent : subtle);
            d.setBounds(0,0,dp(22),dp(22));
            t.setCompoundDrawables(d,null,null,null);
            t.setCompoundDrawablePadding(dp(10));
        }
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(box(prominent ? panelAlt : panel, border, 12));
        t.setOnFocusChangeListener((v,hasFocus) -> {
            t.setBackground(box(hasFocus ? panelAlt : (prominent ? panelAlt : panel),
                    hasFocus ? accent : border,12));
            t.setScaleX(hasFocus ? 1.018f : 1f);
            t.setScaleY(hasFocus ? 1.018f : 1f);
        });
        t.setOnClickListener(v -> click.run());
        return t;
    }
    private void buildUi() {
        palette();
        LinearLayout screen = horizontal();
        screen.setBackgroundColor(bg);
        setContentView(screen);

        ScrollView sideScroll = new ScrollView(this);
        sideScroll.setFillViewport(true);
        sideScroll.setVerticalScrollBarEnabled(false);
        sideScroll.setBackgroundColor(panel);
        sideScroll.setPadding(dp(20), dp(20), dp(20), dp(16));
        screen.addView(sideScroll, new LinearLayout.LayoutParams(dp(246), -1));
        sidebar = vertical(); sidebar.setPadding(dp(2),dp(5),dp(2),dp(8));
        sideScroll.addView(sidebar);

        LinearLayout content = vertical();
        content.setPadding(dp(27),dp(20),dp(26),dp(14));
        screen.addView(content, new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout top = horizontal();
        heading = text("Pamięć TV", 26, fg, true);
        top.addView(heading, new LinearLayout.LayoutParams(0,dp(49),1));
        TextView themeSwitch = action(dark ? "Jasny" : "Ciemny", dark ? ModernIcon.SUN : ModernIcon.MOON,
                false, this::toggleTheme);
        top.addView(themeSwitch, new LinearLayout.LayoutParams(-2,dp(43)));
        content.addView(top);

        pathView = text("", 14, subtle, false);
        pathView.setPadding(0,0,0,0);
        content.addView(pathView, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout tools = horizontal(); tools.setPadding(0,dp(6),0,dp(12));
        addTool(tools,"Wstecz",ModernIcon.BACK,this::goBack);
        addTool(tools,"Nowy folder",ModernIcon.PLUS,this::createFolderDialog);
        addTool(tools,"Wklej",ModernIcon.PASTE,this::paste);
        addTool(tools,"Odśwież",ModernIcon.REFRESH,this::refresh);
        content.addView(tools);

        TextView colHeader = text("NAZWA                                  SZCZEGÓŁY", 12, subtle, true);
        colHeader.setPadding(dp(12), dp(4), 0,dp(7));
        content.addView(colHeader);

        ScrollView listingScroll = new ScrollView(this);
        listingScroll.setFillViewport(true);
        listingScroll.setVerticalScrollBarEnabled(false);
        fileColumn = vertical(); fileColumn.setPadding(dp(1),dp(2),dp(2),dp(10));
        listingScroll.addView(fileColumn);
        content.addView(listingScroll,new LinearLayout.LayoutParams(-1,0,1));

        foot = text(statusText, 12, subtle, false);
        foot.setPadding(dp(7),dp(7),0,0);
        content.addView(foot, new LinearLayout.LayoutParams(-1,dp(30)));
        buildSidebar();
        updateTitle();
    }
    private void addTool(LinearLayout parent,String label,int icon,Runnable callback) {
        TextView t = action(label,icon,false,callback);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2,dp(43));
        lp.rightMargin = dp(10); parent.addView(t,lp);
    }
    private void sideHeader(String value) {
        TextView t = text(value.toUpperCase(Locale.ROOT),11,subtle,true);
        t.setPadding(dp(10),dp(15),dp(4),dp(7));
        sidebar.addView(t);
    }
    private void sideButton(String label,int icon,Runnable callback) {
        TextView t = action(label,icon,false,callback);
        t.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(45));
        lp.bottomMargin = dp(7); sidebar.addView(t,lp);
    }
    private void buildSidebar() {
        if(sidebar==null) return;
        sidebar.removeAllViews();
        TextView brand = text("LOS PLIKOS",22,fg,true);
        brand.setLetterSpacing(0.07f);
        sidebar.addView(brand, new LinearLayout.LayoutParams(-1,dp(40)));
        TextView sub = text("TV  /  FILE MANAGER",11,accent,true);
        sidebar.addView(sub,new LinearLayout.LayoutParams(-1,dp(25)));

        sideHeader("Urządzenie");
        sideButton("Pamięć TV",ModernIcon.TV,() -> openLocal(Environment.getExternalStorageDirectory().getPath()));
        sideButton("Dyski USB",ModernIcon.USB,this::chooseUsb);

        sideHeader("Połączenia sieciowe");
        sideButton("Dodaj serwer FTP",ModernIcon.FTP,() -> showConnectionForm("ftp",null));
        sideButton("Dodaj serwer SMB1",ModernIcon.SMB,() -> showConnectionForm("smb",null));
        if (!bookmarks.isEmpty()) sideHeader("Zapisane serwery");
        for (Filesystems.Endpoint ep : new ArrayList<>(bookmarks)) {
            int icon = ep.type.equals("ftp") ? ModernIcon.FTP : ModernIcon.SMB;
            TextView t = action(ep.title,icon,false,() -> showConnectionForm(ep.type,ep));
            t.setTextSize(13);
            t.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle(ep.title)
                        .setItems(new String[]{"Połącz", "Usuń zapisany serwer"},(d,i)-> {
                            if(i==0)showConnectionForm(ep.type,ep);
                            else new AlertDialog.Builder(this).setMessage("Usunąć wpis z listy serwerów?")
                                    .setPositiveButton("Usuń",(dd,w)->{bookmarks.remove(ep);saveBookmarks();buildSidebar();})
                                    .setNegativeButton("Anuluj",null).show();
                        }).show();
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(44));
            lp.bottomMargin = dp(7);sidebar.addView(t,lp);
        }
        sideHeader("Ustawienia");
        sideButton(dark ? "Motyw: AMOLED Dark" : "Motyw: Light",dark?ModernIcon.MOON:ModernIcon.SUN,this::toggleTheme);
        sideButton("Dostęp do plików",ModernIcon.FOLDER,this::explainPermission);
        TextView version = text("v1.0  •  FTP / SMB1  •  n2s",11,subtle,false);
        version.setPadding(dp(8),dp(23),0,0);
        sidebar.addView(version);
    }

    private void updateTitle() {
        if (current==null || pathView==null) return;
        boolean local = current instanceof Filesystems.Local;
        heading.setText(local ? (current.root().equals(Environment.getExternalStorageDirectory().getPath())
                ? "Pamięć telewizora" : "Nośnik / katalog") : current.label());
        pathView.setText(local ? currentPath : current.label() + "   /   " + currentPath);
    }
    private void status(String message) {
        statusText = message;
        if (foot != null) foot.setText(message);
    }
    private void renderList(List<Filesystems.Entry> items) {
        fileColumn.removeAllViews();
        if (items.isEmpty()) {
            TextView empty = text("Ten folder jest pusty",17,subtle,false);
            empty.setPadding(dp(28),dp(35),0,0);fileColumn.addView(empty);
            return;
        }
        for (Filesystems.Entry item : items) {
            LinearLayout row = horizontal();
            row.setPadding(dp(9),dp(5),dp(6),dp(5));
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1,dp(62));
            rowParams.bottomMargin = dp(6);
            row.setBackground(box(panel,border,13));
            ModernIcon icon = new ModernIcon(item.directory ? ModernIcon.FOLDER : ModernIcon.FILE,
                    item.directory ? accent : subtle);
            android.widget.ImageView image = new android.widget.ImageView(this);
            image.setImageDrawable(icon);
            row.addView(image,new LinearLayout.LayoutParams(dp(29),dp(29)));
            LinearLayout fileTexts = vertical();
            fileTexts.setPadding(dp(14),0,dp(6),0);
            TextView name = text(item.name,16,fg,item.directory);
            TextView detail = text(item.directory ? "Katalog" : formatSize(item.size),12,subtle,false);
            fileTexts.addView(name,new LinearLayout.LayoutParams(-1,dp(27)));
            fileTexts.addView(detail,new LinearLayout.LayoutParams(-1,dp(18)));
            row.addView(fileTexts,new LinearLayout.LayoutParams(0,-2,1));
            TextView date = text(item.modified==0 ? "" : DateFormat.getDateInstance(DateFormat.SHORT).format(new Date(item.modified)),12,subtle,false);
            date.setGravity(Gravity.CENTER); row.addView(date,new LinearLayout.LayoutParams(dp(94),dp(42)));

            TextView menu = action("",ModernIcon.MENU,false,() -> showItemActions(item));
            menu.setPadding(dp(11),dp(9),dp(11),dp(9));
            row.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(42)));
            row.setFocusable(true);
            row.setTag(item);
            menu.setTag(item);
            row.setClickable(true);
            row.setOnClickListener(v -> {
                if (item.directory) { requestListFocus=true; loadFolder(current,item.path,null); }
                else openFile(item);
            });
            row.setOnLongClickListener(v -> {showItemActions(item);return true;});
            row.setOnFocusChangeListener((v,has) -> row.setBackground(box(has?panelAlt:panel,has?accent:border,13)));
            fileColumn.addView(row,rowParams);
        }
        if (requestListFocus && fileColumn.getChildCount()>0) {
            requestListFocus=false;
            fileColumn.getChildAt(0).requestFocus();
        }
    }
    private static String formatSize(long bytes) {
        if(bytes<1024) return Math.max(0,bytes)+" B";
        double n=bytes;String[] unit={"B","KB","MB","GB","TB"};int u=0;
        while(n>=1024 && u<4){n/=1024;u++;}
        return String.format(Locale.getDefault(),"%.1f %s",n,unit[u]);
    }

    private void loadFolder(Filesystems.Store store, String path, Filesystems.Endpoint toSave) {
        int seq = ++generation;
        status("Wczytywanie folderu...");
        workers.execute(() -> {
            try {
                List<Filesystems.Entry> items = store.list(path);
                runOnUiThread(() -> {
                    if (seq!=generation || isFinishing()) return;
                    current=store;currentPath=path;
                    if(toSave!=null) { saveNewBookmark(toSave); buildSidebar(); }
                    updateTitle();renderList(items);
                    status(items.size()+" elementów  •  OK: otwórz  •  ⋮: działania  •  Wstecz: poprzedni folder");
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (seq==generation && !isFinishing()) {
                        status("Błąd połączenia / odczytu");
                        showError(error);
                    }
                });
            }
        });
    }
    private void refresh() { if(current!=null) loadFolder(current,currentPath,null); }
    private void goBack() {
        if (current==null)return;
        if (currentPath.equals(current.root())) {
            if (!(current instanceof Filesystems.Local)) openLocal(Environment.getExternalStorageDirectory().getPath());
            else status("Jesteś w katalogu głównym");
        } else { requestListFocus=true;loadFolder(current,current.parent(currentPath),null); }
    }
    @Override public void onBackPressed() { goBack(); }
    @Override public boolean onKeyDown(int key, KeyEvent event) {
        if (key == KeyEvent.KEYCODE_MENU) {
            View focused=getCurrentFocus();
            if(focused!=null && focused.getTag() instanceof Filesystems.Entry) {
                showItemActions((Filesystems.Entry) focused.getTag());return true;
            }
        }
        return super.onKeyDown(key,event);
    }
    private void openLocal(String folder) {
        try { requestListFocus=true;Filesystems.Store storage = new Filesystems.Local(folder);
            loadFolder(storage,storage.root(),null);
        } catch (Exception e) { showError(e); }
    }
    private void chooseUsb() {
        StorageManager sm = (StorageManager)getSystemService(Context.STORAGE_SERVICE);
        List<StorageVolume> volumes = sm.getStorageVolumes();
        List<File> drives = new ArrayList<>();
        List<String> titles = new ArrayList<>();
        for (StorageVolume vol : volumes) {
            if (!vol.isRemovable()) continue;
            File dir = android.os.Build.VERSION.SDK_INT>=30 ? vol.getDirectory() : null;
            if(dir!=null && dir.exists()) {
                drives.add(dir);titles.add(vol.getDescription(this)+"   •   "+dir.getAbsolutePath());
            }
        }
        if(drives.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Nośniki USB")
                    .setMessage("Nie wykryto dostępnego dysku USB. Sprawdź, czy telewizor go widzi oraz czy aplikacja ma dostęp do plików.")
                    .setPositiveButton("Uprawnienia",(d,w)->explainPermission())
                    .setNegativeButton("Zamknij",null).show();
        } else {
            new AlertDialog.Builder(this).setTitle("Wybierz dysk USB")
                    .setItems(titles.toArray(new String[0]),(d,i)->openLocal(drives.get(i).getAbsolutePath()))
                    .setNegativeButton("Anuluj",null).show();
        }
    }

    private void toggleTheme() {
        dark=!dark;prefs.edit().putBoolean("dark",dark).apply();
        setTheme(dark ? R.style.AppThemeDark : R.style.AppTheme);
        buildUi();refresh();
    }
    private void explainPermission() {
        if(android.os.Build.VERSION.SDK_INT>=30 && Environment.isExternalStorageManager()) {
            new AlertDialog.Builder(this).setTitle("Dostęp do plików")
                    .setMessage("Uprawnienie do zarządzania plikami jest aktywne.")
                    .setPositiveButton("OK",null).show();return;
        }
        if (!firstPermissionPrompt) return;
        firstPermissionPrompt=false;
        new AlertDialog.Builder(this).setTitle("Dostęp do pamięci")
                .setMessage("Android TV 12 wymaga osobnej zgody na zarządzanie plikami. Bez niej przeglądanie i zapis na dysku mogą być ograniczone. W części telewizorów ekran tego uprawnienia nie jest dostępny.")
                .setPositiveButton("Otwórz ustawienia",(d,w)->openPermissionSettings())
                .setNegativeButton("Później",(d,w)->firstPermissionPrompt=true).show();
    }
    private void openPermissionSettings() {
        Intent[] choices = {
                new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName())),
                new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))
        };
        for(Intent i:choices) {
            try{startActivity(i);firstPermissionPrompt=true;return;}
            catch(ActivityNotFoundException ignored) {}
        }
        status("Telewizor nie udostępnia ekranu uprawnień dla aplikacji");
        firstPermissionPrompt=true;
    }
    @Override protected void onResume() {
        super.onResume();
        if(current!=null && fileColumn!=null) refresh();
    }

    private void showConnectionForm(String kind, Filesystems.Endpoint preset) {
        boolean smb = kind.equals("smb");
        LinearLayout form = vertical();form.setPadding(dp(12),dp(8),dp(12),dp(9));
        EditText alias=field(form,"Nazwa połączenia",preset==null ? (smb?"Serwer SMB1":"Serwer FTP") : preset.title,1);
        EditText host=field(form,"Adres IP / host",preset==null?"":preset.host,1);
        EditText port=field(form,"Port",preset==null?(smb?"445":"21"):String.valueOf(preset.port),2);
        EditText user=field(form,"Użytkownik (FTP: anonymous)",preset==null?(smb?"":"anonymous"):preset.user,1);
        EditText pwd=field(form,"Hasło (nie będzie zapisane)","",3);
        EditText share=smb?field(form,"Nazwa udziału SMB",preset==null?"":preset.share,1):null;
        EditText domain=smb?field(form,"Domena / grupa robocza (opcjonalnie)",preset==null?"":preset.domain,1):null;
        ScrollView sc = new ScrollView(this);sc.addView(form);
        String note = smb ? "SMB1 jest przestarzały. Używaj wyłącznie w zaufanej sieci lokalnej."
                : "Zwykły FTP wysyła dane i hasła bez szyfrowania. Używaj tylko w LAN.";
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle(smb?"Połączenie SMB 1.0":"Połączenie FTP")
                .setMessage(note).setView(sc)
                .setPositiveButton("Połącz i zapisz",null)
                .setNeutralButton("Tylko teraz",null)
                .setNegativeButton("Anuluj",null).create();
        dialog.setOnShowListener(v -> {
            View.OnClickListener connect = button -> {
                try {
                    String hostname=host.getText().toString().trim();
                    if (!hostname.matches("[A-Za-z0-9.-]+") || hostname.length()>253)
                        throw new IllegalArgumentException("Podaj prawidłowy adres IP lub nazwę serwera");
                    int p=Integer.parseInt(port.getText().toString().trim());
                    if (p<=0 || p>65535) throw new IllegalArgumentException("Nieprawidłowy numer portu");
                    String sh = smb?share.getText().toString().trim():"";
                    if(smb)Filesystems.cleanName(sh);
                    Filesystems.Endpoint ep = new Filesystems.Endpoint(kind,
                            alias.getText().toString().trim().isEmpty()?hostname:alias.getText().toString().trim(),
                            hostname,p,user.getText().toString().trim(),
                            domain==null?"":domain.getText().toString().trim(),sh,pwd.getText().toString());
                    Filesystems.Store store = smb ? new Filesystems.Smb1(ep) : new Filesystems.Ftp(ep);
                    dialog.dismiss();
                    requestListFocus=true;
                    loadFolder(store,store.root(),button==dialog.getButton(AlertDialog.BUTTON_POSITIVE)?ep:null);
                } catch (Exception e) { showError(e); }
            };
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(connect);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(connect);
        });
        dialog.show();
    }
    private EditText field(LinearLayout form,String hint,String value,int type) {
        TextView label=text(hint,12,subtle,false);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(22));
        lp.topMargin=dp(8);form.addView(label,lp);
        EditText edit=new EditText(this);
        edit.setText(value);edit.setTextColor(fg);edit.setHintTextColor(subtle);
        edit.setTextSize(15);edit.setSingleLine(true);
        if(type==2)edit.setInputType(InputType.TYPE_CLASS_NUMBER);
        else if(type==3)edit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        else edit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);
        edit.setPadding(dp(10),0,dp(8),0);
        edit.setBackground(box(panelAlt,border,8));
        form.addView(edit,new LinearLayout.LayoutParams(-1,dp(43)));
        return edit;
    }
    private void loadBookmarks() {
        bookmarks.clear();
        try {
            JSONArray a=new JSONArray(prefs.getString("servers","[]"));
            for(int i=0;i<a.length();i++) {
                JSONObject j=a.getJSONObject(i);
                bookmarks.add(new Filesystems.Endpoint(j.getString("type"),j.getString("title"),
                        j.getString("host"),j.getInt("port"),j.optString("user",""),
                        j.optString("domain",""),j.optString("share",""),""));
            }
        }catch(Exception ignored){}
    }
    private void saveBookmarks() {
        JSONArray a=new JSONArray();
        for(Filesystems.Endpoint ep:bookmarks) {
            JSONObject j=new JSONObject();
            try {
                j.put("type",ep.type);j.put("title",ep.title);j.put("host",ep.host);
                j.put("port",ep.port);j.put("user",ep.user);j.put("domain",ep.domain);
                j.put("share",ep.share); // no password key intentionally
                a.put(j);
            }catch(Exception ignored){}
        }
        prefs.edit().putString("servers",a.toString()).apply();
    }
    private void saveNewBookmark(Filesystems.Endpoint ep) {
        for(int i=bookmarks.size()-1;i>=0;i--) {
            Filesystems.Endpoint old=bookmarks.get(i);
            if(old.host.equals(ep.host)&&old.type.equals(ep.type)&&old.share.equals(ep.share))
                bookmarks.remove(i);
        }
        bookmarks.add(new Filesystems.Endpoint(ep.type,ep.title,ep.host,ep.port,ep.user,ep.domain,ep.share,""));
        saveBookmarks();
    }

    private void createFolderDialog() {
        if (current==null) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);input.setHint("Nazwa folderu");
        input.setPadding(dp(24),dp(15),dp(24),dp(15));
        new AlertDialog.Builder(this).setTitle("Nowy folder")
                .setView(input).setPositiveButton("Utwórz",(d,w)->{
                    try {
                        String name=Filesystems.cleanName(input.getText().toString());
                        Filesystems.Store store=current;
                        String target=store.child(currentPath,name);
                        perform("Tworzenie folderu...",()->{
                            if(store.exists(target))throw new IOException("Taka nazwa już istnieje");
                            store.mkdir(target);
                        },true);
                    }catch(Exception e){showError(e);}
                }).setNegativeButton("Anuluj",null).show();
    }
    private void showItemActions(Filesystems.Entry item) {
        String[] options = current instanceof Filesystems.Local
                ? new String[]{"Otwórz", "Kopiuj", "Przenieś", "Zmień nazwę", "Usuń"}
                : new String[]{"Otwórz", "Kopiuj", "Przenieś", "Zmień nazwę", "Usuń", "Pobierz do Pobrane"};
        Filesystems.Store itemStore=current;
        new AlertDialog.Builder(this).setTitle(item.name).setItems(options,(d,chosen)->{
            switch(chosen) {
                case 0:
                    if (item.directory) {requestListFocus=true;loadFolder(itemStore,item.path,null);}
                    else openFile(item);
                    break;
                case 1: clipboardStore=itemStore;clipboardItem=item;clipboardMove=false;
                    status("Skopiowano do schowka: " + item.name + "  •  Wybierz folder i naciśnij Wklej");break;
                case 2: clipboardStore=itemStore;clipboardItem=item;clipboardMove=true;
                    status("Przenoszenie: " + item.name + "  •  Wybierz folder docelowy i naciśnij Wklej");break;
                case 3:renameDialog(itemStore,item);break;
                case 4:deleteDialog(itemStore,item);break;
                case 5:download(itemStore,item);break;
            }
        }).setNegativeButton("Anuluj",null).show();
    }
    private void renameDialog(Filesystems.Store store,Filesystems.Entry item) {
        EditText edit = new EditText(this);edit.setSingleLine(true);edit.setText(item.name);
        edit.setSelectAllOnFocus(true);edit.setPadding(dp(18),dp(16),dp(18),dp(16));
        new AlertDialog.Builder(this).setTitle("Zmień nazwę")
                .setView(edit).setPositiveButton("Zapisz",(d,w)->{
                    try {
                        String name=Filesystems.cleanName(edit.getText().toString());
                        String target=store.child(store.parent(item.path),name);
                        if(target.equals(item.path))return;
                        perform("Zmiana nazwy...",()->{
                            if(store.exists(target))throw new IOException("Taka nazwa już istnieje");
                            store.rename(item.path,target);
                        },true);
                    }catch(Exception e){showError(e);}
                }).setNegativeButton("Anuluj",null).show();
    }
    private void deleteDialog(Filesystems.Store store,Filesystems.Entry item) {
        new AlertDialog.Builder(this).setTitle("Usunąć " + item.name + "?")
                .setMessage(item.directory ? "Folder i WSZYSTKIE pliki w nim zostaną bezpowrotnie usunięte."
                        : "Plik zostanie bezpowrotnie usunięty.")
                .setPositiveButton("Usuń",(d,w)->perform("Usuwanie...",()->store.delete(item.path),true))
                .setNegativeButton("Anuluj",null).show();
    }
    private void paste() {
        if(clipboardStore==null || clipboardItem==null){status("Schowek jest pusty");return;}
        Filesystems.Store source=clipboardStore,to=current;
        Filesystems.Entry entry=clipboardItem;
        String destFolder=currentPath;
        boolean moving=clipboardMove;
        if(moving && source==to && source.parent(entry.path).equals(destFolder)){
            status("Plik jest już w tym folderze");return;
        }
        boolean sameDisk = source == to ||
                (source instanceof Filesystems.Local && to instanceof Filesystems.Local) ||
                (source instanceof Filesystems.Ftp && to instanceof Filesystems.Ftp &&
                        ((Filesystems.Ftp)source).ep.host.equals(((Filesystems.Ftp)to).ep.host) &&
                        ((Filesystems.Ftp)source).ep.port==((Filesystems.Ftp)to).ep.port) ||
                (source instanceof Filesystems.Smb1 && to instanceof Filesystems.Smb1 &&
                        ((Filesystems.Smb1)source).ep.host.equals(((Filesystems.Smb1)to).ep.host) &&
                        ((Filesystems.Smb1)source).ep.share.equals(((Filesystems.Smb1)to).ep.share));
        if(entry.directory && sameDisk &&
                (destFolder.equals(entry.path) || destFolder.startsWith(entry.path+"/"))) {
            showError(new IOException("Nie można kopiować folderu do jego własnego podfolderu"));return;
        }
        perform(moving?"Przenoszenie plików...":"Kopiowanie plików...",()->{
            String target=Filesystems.uniqueName(to,destFolder,entry.name,entry.directory);
            Filesystems.copy(source,entry,to,target);
            if(moving) {
                source.delete(entry.path);
                runOnUiThread(() -> {
                    if(clipboardStore==source && clipboardItem==entry) {
                        clipboardStore=null;clipboardItem=null;clipboardMove=false;
                    }
                });
            }
        },true);
    }
    private void download(Filesystems.Store from,Filesystems.Entry item) {
        File downloads=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if(android.os.Build.VERSION.SDK_INT>=30 && !Environment.isExternalStorageManager()) {
            File fallback=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if(fallback!=null) downloads=fallback;
        }
        File targetDir=downloads;
        perform("Pobieranie do " + targetDir.getAbsolutePath(),()->{
            if(!targetDir.exists()&&!targetDir.mkdirs())throw new IOException("Nie można utworzyć katalogu Pobrane");
            Filesystems.Local dst=new Filesystems.Local(targetDir.getAbsolutePath());
            String target=Filesystems.uniqueName(dst,dst.root(),item.name,item.directory);
            Filesystems.copy(from,item,dst,target);
        },true);
    }
    private void openFile(Filesystems.Entry item) {
        Filesystems.Store from=current;
        if (from instanceof Filesystems.Local) {
            try{viewFile(new File(item.path));}catch(Exception e){showError(e);}
            return;
        }
        if(item.size>400L*1024*1024) {
            new AlertDialog.Builder(this).setTitle("Duży plik")
                    .setMessage("Aby otworzyć plik z FTP/SMB, aplikacja najpierw kopiuje go do pamięci tymczasowej. Plik ma "+formatSize(item.size)+". Lepiej pobrać go do katalogu Pobrane.")
                    .setPositiveButton("Pobierz",(d,w)->download(from,item))
                    .setNegativeButton("Anuluj",null).show();return;
        }
        perform("Otwieranie pliku sieciowego...",()->{
            File cache=new File(getCacheDir(),"preview");
            if(!cache.exists()&&!cache.mkdirs())throw new IOException("Brak miejsca na podgląd");
            Filesystems.Local dst=new Filesystems.Local(cache.getAbsolutePath());
            String output=Filesystems.uniqueName(dst,dst.root(),item.name,false);
            Filesystems.copy(from,item,dst,output);
            runOnUiThread(()->viewFile(new File(output)));
        },false);
    }
    private void viewFile(File file) {
        String name=file.getName();int dot=name.lastIndexOf('.');
        String ext=dot<0?"":name.substring(dot+1).toLowerCase(Locale.ROOT);
        String mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        if(mime==null)mime="*/*";
        try {
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",file);
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri,mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch(Exception e) {
            new AlertDialog.Builder(this).setTitle("Nie można otworzyć pliku")
                    .setMessage("Zainstaluj odtwarzacz lub aplikację obsługującą ten typ pliku.\n\n"+e.getMessage())
                    .setPositiveButton("OK",null).show();
        }
    }
    private interface Operation { void run() throws Exception; }
    private void perform(String message,Operation action,boolean update) {
        status(message);
        workers.execute(()->{
            try {
                action.run();
                runOnUiThread(()->{
                    status("Operacja zakończona");
                    if(update)refresh();
                });
            }catch(Exception e){runOnUiThread(()->showError(e));}
        });
    }
    private void showError(Exception e) {
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        if(msg.length()>240)msg=msg.substring(0,240);
        status("Błąd: " + msg);
        new AlertDialog.Builder(this).setTitle("Nie udało się wykonać operacji")
                .setMessage(msg).setPositiveButton("OK",null).show();
    }
    @Override protected void onDestroy() {
        generation++;
        workers.shutdownNow();
        super.onDestroy();
    }
}
