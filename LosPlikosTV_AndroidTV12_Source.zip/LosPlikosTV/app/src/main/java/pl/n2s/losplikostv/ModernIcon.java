package pl.n2s.losplikostv;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/** Scalable outlined modern icons; no emoji-font dependency on Android TV. */
final class ModernIcon extends Drawable {
    static final int FOLDER=0, FILE=1, TV=2, USB=3, FTP=4, SMB=5,
            SUN=6, MOON=7, PLUS=8, REFRESH=9, PASTE=10, MENU=11, BACK=12;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int type;
    private final int tint;
    ModernIcon(int type, int tint) { this.type = type; this.tint = tint; }
    @Override public void draw(Canvas canvas) {
        Rect r = getBounds();
        int sc = canvas.save();
        canvas.translate(r.left, r.top);
        canvas.scale(r.width()/24f, r.height()/24f);
        p.setColor(tint); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.8f);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
        switch (type) {
            case FOLDER:
                Path folder = new Path(); folder.moveTo(2,7); folder.lineTo(9,7);
                folder.lineTo(11,9); folder.lineTo(22,9); folder.lineTo(22,19);
                folder.quadTo(22,21,20,21); folder.lineTo(4,21);
                folder.quadTo(2,21,2,19); folder.close(); canvas.drawPath(folder,p); break;
            case FILE:
                Path file = new Path(); file.moveTo(6,2);file.lineTo(14,2);file.lineTo(19,7);
                file.lineTo(19,21);file.lineTo(6,21);file.close();canvas.drawPath(file,p);
                canvas.drawLine(14,2,14,7,p);canvas.drawLine(14,7,19,7,p);
                canvas.drawLine(9,12,16,12,p);canvas.drawLine(9,16,16,16,p);break;
            case TV:
                canvas.drawRoundRect(2,4,22,18,2,2,p);
                canvas.drawLine(9,21,15,21,p);canvas.drawLine(12,18,12,21,p);break;
            case USB:
                canvas.drawLine(12,20,12,4,p);canvas.drawLine(12,10,6,10,p);
                canvas.drawLine(6,10,6,6,p);canvas.drawCircle(6,5,1.5f,p);
                canvas.drawLine(12,14,18,14,p);canvas.drawLine(18,14,18,10,p);
                canvas.drawRect(16.5f,7,19.5f,10,p);canvas.drawLine(9,20,15,20,p);break;
            case FTP:
                canvas.drawCircle(12,12,9,p);canvas.drawOval(8,3,16,21,p);
                canvas.drawLine(3,12,21,12,p);canvas.drawLine(5,7,19,7,p);
                canvas.drawLine(5,17,19,17,p);break;
            case SMB:
                canvas.drawRoundRect(2,3,22,10,2,2,p);canvas.drawRoundRect(2,14,22,21,2,2,p);
                canvas.drawCircle(6,6.5f,1,p); canvas.drawCircle(6,17.5f,1,p);
                canvas.drawLine(11,6.5f,18,6.5f,p);canvas.drawLine(11,17.5f,18,17.5f,p);break;
            case SUN:
                canvas.drawCircle(12,12,4,p);
                for(int i=0;i<8;i++){double a=i*Math.PI/4;canvas.drawLine(12+(float)Math.cos(a)*7,12+(float)Math.sin(a)*7,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10,p);}break;
            case MOON:
                Path moon = new Path();moon.moveTo(17,3);moon.cubicTo(5,2,4,18,16,20);
                moon.cubicTo(8,23,2,15,6,8);moon.cubicTo(8,4,12,2,17,3);canvas.drawPath(moon,p);break;
            case PLUS:
                canvas.drawLine(12,4,12,20,p);canvas.drawLine(4,12,20,12,p);break;
            case REFRESH:
                canvas.drawArc(4,4,20,20,40,290,false,p);
                canvas.drawLine(19,7,19,3,p);canvas.drawLine(19,7,15,7,p);break;
            case PASTE:
                canvas.drawRoundRect(5,5,19,22,2,2,p);
                canvas.drawRoundRect(9,2,15,8,1,1,p);canvas.drawLine(8,13,16,13,p);
                canvas.drawLine(8,17,14,17,p);break;
            case MENU:
                p.setStyle(Paint.Style.FILL);
                canvas.drawCircle(12,5,1.6f,p);canvas.drawCircle(12,12,1.6f,p);
                canvas.drawCircle(12,19,1.6f,p);break;
            case BACK:
                canvas.drawLine(20,12,4,12,p);canvas.drawLine(4,12,11,5,p);
                canvas.drawLine(4,12,11,19,p);break;
        }
        canvas.restoreToCount(sc);
    }
    @Override public void setAlpha(int alpha) { p.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { p.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    @Override public int getIntrinsicWidth() { return 28; }
    @Override public int getIntrinsicHeight() { return 28; }
}
